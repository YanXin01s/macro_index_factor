jax.experimental.maps module
============================

.. automodule:: jax.experimental.maps

API
---

.. autosummary::
   :toctree: _autosummary

   Mesh
   xmap
