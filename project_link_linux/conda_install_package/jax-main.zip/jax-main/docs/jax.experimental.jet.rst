jax.experimental.jet module
===========================

.. automodule:: jax.experimental.jet

API
---

.. autofunction:: jet
