jax.sharding package
====================

.. automodule:: jax.sharding

Classes
-------

.. currentmodule:: jax.sharding

.. autoclass:: Sharding
   :members:
.. autoclass:: XLACompatibleSharding
   :members:
   :show-inheritance:
.. autoclass:: NamedSharding
   :members:
   :show-inheritance:
.. autoclass:: SingleDeviceSharding
   :members:
   :show-inheritance:
