import warnings


warnings.warn(
    "The module `pytensor.link.jax.jax_linker` is deprecated "
    "and has been renamed to `pytensor.link.jax.linker`",
    DeprecationWarning,
    stacklevel=2,
)
