import warnings


warnings.warn(
    "The module `pytensor.link.jax.jax_dispatch` is deprecated "
    "and has been renamed to `pytensor.link.jax.dispatch`",
    DeprecationWarning,
    stacklevel=2,
)
