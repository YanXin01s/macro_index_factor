import warnings


warnings.warn(
    "The module `pytensor.graph.toolbox` is deprecated "
    "and has been renamed to `pytensor.graph.features`",
    DeprecationWarning,
    stacklevel=2,
)
